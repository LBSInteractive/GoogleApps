chrome.devtools.panels.create("DavLink",
    "app/site_media/logo/NetLink-48.png",
    "app/html/panelSniffer/panelSniffer.html",
    function(panel) {
        console.log('/**DavLink Iniciado**/');
    }
);
